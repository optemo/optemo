// #include "ClpInterior.hpp"
// #include "ClpSimplex.hpp"
// #include "ClpCholeskyWssmp.hpp"
// #include "ClpCholeskyDense.hpp"

// Standard C++ includes
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <assert.h>
#include <float.h>
#include <math.h>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

#include <cppconn/mysql_public_iface.h>
//

using namespace std;

int main(int argc, char** argv){	
   stringstream sql;	
	sql::mysql::MySQL_Driver *driver;

	// Connection, (simple, not prepared) Statement, Result Set
	sql::Connection	*con;
	sql::Statement	*stmt;
	
	
	 #define PORT "3306"       
		#define DB   "optemo_development"
		#define HOST "jaguar"
		#define USER "maryam" 
	    #define PASS "sCbub3675NWnNZK2" 
	
///////////////////////////////////////////////
			try {
				
				// Using the Driver to create a connection
				driver = sql::mysql::get_mysql_driver_instance();
				con = driver->connect(HOST, PORT, USER, PASS);
				stmt = con->createStatement();
				string command = "USE ";
				command += databaseName;
				
				stmt->execute(command);
				
					delete stmt;
				 	delete con;

				 	}catch (sql::mysql::MySQL_DbcException *e) {

						delete e;
						return EXIT_FAILURE;

					} catch (sql::DbcException *e) {
						/* Exception is not caused by the MySQL Server */

						delete e;
						return EXIT_FAILURE;
					}


				return 1; //EXIT_SUCCESS;
			}
				